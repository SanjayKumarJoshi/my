var app       =     require("express")();
 
var http      =     require('http').Server(app);
var io        =     require("socket.io")(http);

 var path = require('path');
var bodyParser = require("body-parser");


app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));


app.get("/",function(req,res){
    res.sendFile(__dirname + '/index.html');
});


app.post("/", function(req, res) {
   /* if(!req.body.username || !req.body.password || !req.body.twitter) {
        return res.send({"status": "error", "message": "missing a parameter"});
    } else {
        return res.send(req.body.method);
    }
	*/

var data=req.body;
console.log(data);
//console.log(JSON.stringify(data));
var data=JSON.parse(JSON.stringify(data));
tagID=data.tagid;
rssi=data.rssi;
time=data.time;
  io.emit('refresh feed',JSON.stringify(data));
});



/*  This is auto initiated event when Client connects to Your Machien.  */

io.on('connection',function(socket){  
    console.log("A user is connected");
    socket.on('status added',function(status){
		console.log("received"+status);
       
		  
      
            io.emit('refresh feed',status);
      
    });
});

var add_status = function (status,callback) {
    
}

http.listen(3000,function(){
    console.log("Listening on 3000");
});